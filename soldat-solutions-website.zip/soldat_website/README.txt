SOLDAT SOLUTIONS WEBSITE

Files:
- index.html
- styles.css
- script.js
- assets/soldat-logo.png

Before publishing:
1. Replace contact@soldatsolutions.com in index.html with your actual email.
2. Add your phone number, location, and any certifications/registrations you want displayed.
3. Update services or language as needed.
4. Upload the folder contents to Squarespace (code block/developer mode), Netlify, GitHub Pages, GoDaddy, Wix Studio, or another web host.

The contact form currently opens the visitor's email application. A true online form requires a form service or hosting backend.
